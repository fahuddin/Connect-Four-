#
# ps9pr4.py  (Problem Set 9, Problem 4)
#
# AI Player for use in Connect Four   
#

import random  
from ps9pr3 import *

class AIPlayer(Player):
    """will look ahead some number of moves into the future to assess the impact of each possible move that it could make for its next move, and it will assign a score to each possible move. And since each move corresponds to a column number, it will effectively assign a score to each column."""
    
    def __init__(self, checker, tiebreak, lookahead):
        """constructs a new AIPlayer object. Begin the method with assert statements that validate the inputs"""
        assert(checker == 'X' or checker == 'O')
        assert(tiebreak == 'LEFT' or tiebreak == 'RIGHT' or tiebreak == 'RANDOM')
        assert(lookahead >= 0)
        super().__init__(checker)
        self.tiebreak = tiebreak
        self.lookahead = lookahead 
   
    
    def __repr__(self):
        """returns a string representing an AIPlayer object. This method will override/replace the __repr__ method that is inherited from Player. In addition to indicating which checker the AIPlayer object is using, the returned string should also indicate the player’s tiebreaking strategy and lookahead"""
        x = self.checker 
        y = self.tiebreak
        z = self.lookahead
        return 'Player '+x+' ('+y+', '+str(z)+')'
    
    def max_score_column(self, scores):
        """takes a list scores containing a score for each column of the board, and that returns the index of the column with the maximum score. If one or more columns are tied for the maximum score, the method should apply the called AIPlayer‘s tiebreaking strategy to break the tie"""
        s = max(scores)
        indices = []
        for x in range(len(scores)):
              if s == scores[x]:
                  indices += [x]
        if self.tiebreak == 'RANDOM':
             return random.choice(indices)
        if self.tiebreak == 'RIGHT':
             return indices[-1]
        if self.tiebreak == 'LEFT':
             return indices[0]
     
    def scores_for(self,b):
        """takes a Board object b and determines the called AIPlayer‘s scores for the columns in b"""
        scores = [50] * b.width
        for col in range(b.width):
            if b.can_add_to(col) == False:
                scores[col] = -1 
            elif b.is_win_for(self.checker):
                scores[col] = 100
            elif b.is_win_for(self.opponent_checker()):
                scores[col] = 0 
            elif self.lookahead == 0:
                scores[col] = 50
            else:
                b.add_checker(self.checker,col)
                x = AIPlayer(self.opponent_checker(), self.tiebreak, self.lookahead - 1)
                opp_scores = x.scores_for(b)
                if max(opp_scores) == 100:
                    scores[col] = 0
                elif max(opp_scores) == 0:
                    scores[col] = 100
                elif max(opp_scores) == 50:
                    scores[col] = 50 
                b.remove_checker(col)
        return scores 
    
    def next_move(self, b):
        """overrides (i.e., replaces) the next_move method that is inherited from Player"""
        self.num_moves +=1
        y = self.scores_for(b)
        return self.max_score_column(y)
    
               
                
            
                
            
                
                
            
        
    
    
     
       